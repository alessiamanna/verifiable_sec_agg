#include "server.h"
#include "common.h"
#include "puf_data.h"
#include <fcntl.h>
#include <mqueue.h>
#include <stdio.h>


void calc_share(server_t *srv, node_id_t client_id, payload_t *share_out){
    int index = srv->puf_state;

    for(int i = 0; i < PUF_ITERATIONS; i++){
        
        int current_idx = index + i;

        uint128_t global_mask_sum = 0;
        uint128_t target_mask = 0;

        for(int i = 0; i < MAX_NUM_CLIENTS; i++){
            if(srv->rcvd_updates[i] == 1){
                uint128_t mask_val = theta_function(PUF_CHAIN_TA[i], current_idx);

                global_mask_sum += mask_val;

                if((i + 1) == client_id){
                    target_mask = mask_val;
                }
            }
        }

        share_out[i] = global_mask_sum - target_mask;
    }
}


void server_process_updates(server_t *srv){
    printf("[SERVER} Processing updates at server ID %d\n", srv->server_id);

    // prendo packet from queue
    packet_t pkt;

    if(mq_receive(srv->mq_srv, (char*)&pkt, MSG_SIZE, NULL) == -1){
        perror("mq_receive failed");
        return;
    } 

    if(pkt.puf_state != srv->puf_state){
        printf("synch mismatch");
        return;
    }
    node_id_t client_idx = pkt.client_id - 1;

    if(srv->rcvd_updates[client_idx] == 1){
        printf("Duplicated packet, dropping. \n");
    }
    
    // check for authenticity adn integrity
    private_key_t srv_hmac_key;
    int hmac_idx = (srv->puf_state + PUF_ITERATIONS) % CHAIN_LEN;

    // get ky for the hmac
    srv_hmac_key = (private_key_t)(PUF_CHAIN_SRV[hmac_idx]);

    // compute hmac and compare with received one
    private_key_t computed_hmac = calc_hmac_sign(pkt.payload, sizeof(pkt.payload), srv_hmac_key);
    if(computed_hmac != pkt.hmac_sign){
        printf("[SERVER] HMAC verification failed for client ID %d\n", pkt.client_id);
        return;
    }else{
        printf("[SERVER] HMAC verification succeeded for client ID %d\n", pkt.client_id);
    }


    // we have to retrieve the update
    int index = srv->puf_state % CHAIN_LEN;

    //next, get obfuscated payload
    for(int i = 0; i < PUF_ITERATIONS; i++){
        uint128_t puf_response_srv = theta_function(PUF_CHAIN_SRV, index + i );
        srv->acc[i] += (pkt.payload[i] ^ puf_response_srv);
    }

    srv->rcvd_updates[client_idx] = 1; 

    srv->num_clients += 1;

    if(srv->num_clients >= CLIENTS_PER_ROUND){
        printf("[SERVER] Round complete, broadcsting to clients\n");
        srv->current_state = server_broadcast;
    }
    
}

void server_broadcast(server_t *srv){
    printf("[SERVER] Broadcasting aggregated update from server ID %d\n", srv->server_id);

    for(int i = 0; i < MAX_NUM_CLIENTS; i++){

        //send updates only to active clients 
        if(srv->rcvd_updates[i] == 0){
            continue; 
        }
        node_id_t client_id = i + 1;

        srv_packet_t srv_pkt; 
        memset(&srv_pkt, 0, sizeof(srv_packet_t));

        //copy cumulated sum
        memcpy(srv_pkt.aggr_sum, srv->acc, sizeof(srv->acc));
        
        // calculate the shares. <- dubbi su questa parte, è safe che il server abbia le share dalla TA?
        // for now calculation is only simulated, no real TA sending them

        calc_share(srv, client_id, srv_pkt.shares);

        srv_pkt.server_id = srv->server_id;
        srv_pkt.active_count = srv->num_clients;
        srv_pkt.puf_state = srv->puf_state;

        //solito hmac

        int hmac_idx = (srv->puf_state + PUF_ITERATIONS) % CHAIN_LEN;

        private_key_t sign_key = (private_key_t)(PUF_CHAIN_SRV[hmac_idx]);

        srv_pkt.hmac_sign = calc_hmac_sign(&srv_pkt, sizeof(srv_packet_t) - sizeof(private_key_t), sign_key);

        //send packet to clients

        if(srv->mq_clients[i] == -1){
            char queue_name[32];
            snprintf(queue_name,32,"/client_queue_%d", client_id);
            srv->mq_clients[i] = mq_open(queue_name, O_WRONLY);
        }

        if(srv->mq_clients[i] != -1){
            mq_send(srv->mq_clients[i], (char*)&srv_pkt, sizeof(srv_packet_t), 0);
            printf("[SERVER] Broadcast sent to client ID %d\n", client_id);
        }

        memset(srv->rcvd_updates, 0, sizeof(srv->rcvd_updates));
        memset(srv->acc, 0, sizeof(srv->acc));
        srv->num_clients = 0;

        srv->puf_state = (srv->puf_state + PUF_ITERATIONS + 1) % CHAIN_LEN;
        srv->current_state = server_process_updates;
    }
    /*
    srv_packet_t srv_pkt;
    memset(&srv_pkt, 0, sizeof(srv_packet_t));

    //server has to send m2 = x_sum_obf || share and m3 = hmac(m2)
    memcpy(srv_pkt.aggr_sum, srv->acc, sizeof(srv->acc));


    //shares
    */


}



void run_server_state(server_t *srv) {
    srv->current_state(srv);
}

server_t create_server(as_id_t server_id) {
    server_t srv;
    srv.server_id = server_id;
    srv.puf_state = INITIAL_LINK;
    srv.current_state = server_process_updates;

    memset(srv.rcvd_updates, 0, sizeof(srv.rcvd_updates));
    memset(srv.acc, 0, sizeof(srv.acc));

    for(int i = 0; i < CLIENTS_PER_ROUND; i++){
        srv.mq_clients[i] = -1; 
    }

    struct mq_attr attr = {
        .mq_maxmsg = 10,
        .mq_msgsize = MSG_SIZE,
        .mq_flags = 0
    };

    mq_unlink("/srv_queue");
    srv.mq_srv = mq_open("/srv_queue", O_CREAT | O_RDONLY, 0660, &attr);

    if(srv.mq_srv == -1){
        perror("Server mq_open failed");
    }
    return srv;
}


