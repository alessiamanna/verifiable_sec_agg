#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <mqueue.h>
#include <signal.h>

#include "common.h"
#include "client.h"
#include "server.h"


//non funziona :( 

void run_server_process(){
    server_t srv = create_server(0);

    printf("[SERVER %d] started", srv.server_id);

    while(1){
        run_server_state(&srv);
    }
}

void run_client_process(node_id_t client_id){
    device_t dev = create_device(client_id);

    printf("[CLIENT %d] started", dev.client_id);

    for(int round = 1; round <= 2; round++){
        run_device_state(&dev);

        run_device_state(&dev);

        dev.data_update[0] = 20* round;
        printf("[CLIENT %d] FINISHED ROUND %d", dev.client_id, round);
    }

    mq_close(dev.mq_srv);
    mq_close(dev.mq_client);
    exit(0);
}

int main(){

     mq_unlink("/srv_queue");

    for(int i = 0; i <= MAX_NUM_CLIENTS; i++){
        char name[64];
        snprintf(name, 64, "/client_queue_%d", i);
        mq_unlink(name);
    }
    
    printf("Starting protocol\n");

    pid_t srv_pid = fork();

    if(srv_pid == 0){
        run_server_process();
    }

    sleep(1);

    pid_t client_pids[MAX_NUM_CLIENTS];

    for(int i = 0; i < MAX_NUM_CLIENTS; i++){
        if((client_pids[i] = fork()) == 0){
            run_client_process(i + 1);
        }
    }

    for(int i = 0; i < MAX_NUM_CLIENTS; i++){
        waitpid(client_pids[i], NULL, 0);
    }

    printf("end of protocol \n");

    kill(srv_pid, SIGTERM);

    waitpid(srv_pid, NULL, 0);

   

    return 0;
}