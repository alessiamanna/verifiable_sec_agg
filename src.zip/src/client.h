#ifndef CLIENT_H
#define CLIENT_H

#include "common.h"
#include <mqueue.h>

typedef struct device_s device_t;
typedef void (*state_function_t)(device_t*);

typedef uint16_t device_update_t;

typedef struct device_s{
    node_id_t client_id;
    puf_state_t puf_state;

    //add message queues 
    mqd_t mq_srv; //send messages to server
    mqd_t mq_client; //receive messages from server


    state_function_t current_state;
    device_update_t data_update[UPDATE_LEN];

} device_t;

device_t create_device(node_id_t client_id);

void run_device_state(device_t* dev);

void device_init(device_t* dev);
void device_tx(device_t* dev);
void device_rx(device_t* dev);


#endif