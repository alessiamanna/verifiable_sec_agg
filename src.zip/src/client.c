#include "client.h"
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <mqueue.h>
#include "common.h"
#include "puf_data.h"

void get_client_queue_name(node_id_t client_id, char* queue_name, size_t size){
    snprintf(queue_name, size, "/client_queue_%d", client_id);
}

void device_init(device_t* dev){
    printf("[DEVICE] Init state, client ID %d", dev->client_id);
    dev->puf_state = INITIAL_LINK;
    dev->current_state = device_tx;   
}

void device_tx(device_t* dev){
    printf("[DEVICE] TX state, client ID %d\n", dev->client_id);

    packet_t pkt;
    memset(&pkt, 0, sizeof(packet_t));

    int index = dev->puf_state % CHAIN_LEN;

    const uint128_t* link_ta = PUF_CHAIN_TA[dev->client_id - 1];
    const uint128_t* link_srv = PUF_CHAIN_SRV;

    //padding update data, for now zero padding
    uint8_t padded_update[PAYLOAD_SIZE];
    memset(padded_update, 0, PAYLOAD_SIZE);

    memcpy(padded_update, dev->data_update, UPDATE_SIZE);

    //copy client ID
    pkt.client_id = dev->client_id;
    pkt.puf_state = dev->puf_state;

    // payload aka m0
    uint128_t* obf_update = (uint128_t*)padded_update;

    for(int i = 0; i < PUF_ITERATIONS; i++){
        uint128_t puf_response_ta = theta_function(link_ta, index + i);
        uint128_t puf_response_srv = theta_function(link_srv, index + i);

        pkt.payload[i] = (obf_update[i] + puf_response_ta) ^ puf_response_srv;
    }

    // compute and append HMAC
    private_key_t hmac_key;

    int hmac_idx = (dev->puf_state + PUF_ITERATIONS) % CHAIN_LEN;

    hmac_key = (private_key_t)(link_srv[hmac_idx]);

    pkt.hmac_sign = calc_hmac_sign(pkt.payload, sizeof(pkt.payload), hmac_key);

    printf("[DEVICE] Sending packet with HMAC: 0x%08X\n", pkt.hmac_sign);

    // send packet to server
    if(mq_send(dev->mq_srv,(char*)&pkt, sizeof(packet_t), 0) == -1){
        perror("mq_send failed");
    }else{
        printf("[DEVICE] Packet sent to server from client ID %d\n", dev->client_id);
    }
    
    // update device state
    dev->current_state = device_rx;
}

void device_rx(device_t* dev){
    printf("[DEVICE] RX state, client ID %d\n", dev->client_id);

    // gets packet from server
    srv_packet_t srv_pkt;

    if(mq_receive(dev->mq_client, (char*)&srv_pkt, MSG_SIZE, NULL) == -1){
        perror("mq_receive failed");
        return;
    }

    printf("[DEVICE] Packet received from server ID %d, client ID %d\n", srv_pkt.server_id, dev->client_id);

    //check HMAC for cumulated sum || share
    int hmac_idx = (srv_pkt.puf_state + PUF_ITERATIONS) % CHAIN_LEN;
    private_key_t dev_sign = (private_key_t)theta_function(PUF_CHAIN_SRV, hmac_idx);

    private_key_t calc_sign = calc_hmac_sign(&srv_pkt, sizeof(srv_packet_t) - sizeof(private_key_t), dev_sign);
    if(calc_sign != srv_pkt.hmac_sign){
        printf("[DEVICE] mismatch in expected and received hmac, client ID %d", dev->client_id);
        printf("Expected: 0x%08X, got: 0x%08X\n", calc_sign, srv_pkt.hmac_sign);
        return;
    }

    printf("[DEVICE %d] HMAC verified on xsum || share", dev->client_id);

    int index = srv_pkt.puf_state;

    const uint128_t* link_ta = PUF_CHAIN_TA[dev->client_id - 1];

    uint128_t cumulative_sum[PUF_ITERATIONS];
    memset(cumulative_sum, 0, sizeof(cumulative_sum));

    for(int i = 0; i < PUF_ITERATIONS; i++){
        uint128_t share = srv_pkt.shares[i];

        uint128_t client_share = theta_function(link_ta, index + i);

        cumulative_sum[i] = srv_pkt.aggr_sum[i] - (share + client_share);
    }
    
    uint16_t* val = (uint16_t*)cumulative_sum;

    printf("[DEVICE %d] final sum: %d (expected %d)\n", dev->client_id, val[0], 10*4);

    //update puf state conisdering all consumed links
    dev->puf_state = (dev->puf_state + (PUF_ITERATIONS + 1)) % CHAIN_LEN;
    
    dev->current_state = device_tx;
}

void run_device_state(device_t *dev){
    dev->current_state(dev);
}

device_t create_device(node_id_t client_id){
    device_t dev = {
        .client_id = client_id,
        .puf_state = INITIAL_LINK,
        .current_state = device_init,
        .data_update = {0},
    };

    while((dev.mq_srv = mq_open("/srv_queue", O_WRONLY)) == -1){
        // wait server for queue 
        perror("mq_open failed, retrying...");
        sleep(1);
    }

    char queue_name[32];
    get_client_queue_name(client_id, queue_name, sizeof(queue_name));
    struct mq_attr attr = {
        .mq_maxmsg = 10,
        .mq_msgsize = MSG_SIZE,
        .mq_flags = 0
    };

    mq_unlink(queue_name);
    dev.mq_client = mq_open(queue_name, O_CREAT | O_RDONLY, 0660, &attr);

    if(dev.mq_client == -1){
        perror("Client mq_open failed");
        exit(1);
    }
    return dev;
}