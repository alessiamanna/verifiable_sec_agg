#include <stdio.h>

void A(){
    printf("Funzione A\n");
}

//callback function

void B(void (*ptr)()){
    (*ptr)();
}

int add(int a, int b){
    return a+b;
}

int main(){
    
    int (*fptr)(int,int);

    fptr = &add;

    printf("%d", fptr(10, 5));

    //faccio un puntatore alla funzione che deve essere callbacked da B
    void (*ptr)() = &A;

    B(ptr);

    return 0;
}

