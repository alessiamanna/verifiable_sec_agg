#ifndef SERVER_H
#define SERVER_H

#include "common.h"
#include <stdint.h>

#include <mqueue.h>

typedef struct server_s server_t;
typedef void (*server_state_function_t)(server_t*);


typedef struct server_s{
    as_id_t server_id;
    //metti dopo il resto, ricorda che ci vuole un array per tracciare i client
    uint8_t rcvd_updates[MAX_NUM_CLIENTS]; 

    puf_state_t puf_state;
    server_state_function_t current_state;

    mqd_t mq_srv;
    mqd_t mq_clients[CLIENTS_PER_ROUND];


    uint128_t acc[PUF_ITERATIONS]; // accumulator for the updates
    int num_clients;
    
} server_t;

server_t create_server(as_id_t server_id);

void calc_share(server_t* srv, node_id_t client_id, payload_t* share_out);

void run_server_state(server_t* srv);

void server_broadcast(server_t* srv);
void server_process_updates(server_t* srv);

#endif