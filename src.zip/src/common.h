#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#define INITIAL_LINK 0 
// puf chain length
#define CHAIN_LEN 25

// let's assume the update vector is made of 20 components, 16 bits each
#define UPDATE_LEN 20 

// size of the payload, 20 components of 16 bits each
#define UPDATE_SIZE (UPDATE_LEN * sizeof(uint16_t)) //40byte

// number of PUF iterations needed to cover the payload: 20*16 = 320 bits / 128 bits = 3 iterations
// placeholder number to test all possible edge cases
#define PUF_ITERATIONS  ((UPDATE_SIZE + sizeof(uint128_t) - 1) / sizeof(uint128_t))


// size effettiva considering that the packet sent should have the same size has teh chained puf responses 
#define PAYLOAD_SIZE (PUF_ITERATIONS * sizeof(uint128_t)) 

#define CLIENTS_PER_ROUND 4

#define MAX_NUM_CLIENTS 4


#define MSG_SIZE sizeof(packet_t) > sizeof(srv_packet_t) ? sizeof(packet_t) : sizeof(srv_packet_t)

//current link index in the puf chain
typedef int puf_state_t;

//client node identifier and server identifier
typedef uint16_t node_id_t;
typedef uint16_t as_id_t; 

//type for HMAC
typedef uint32_t private_key_t;

// define 128bits type. C23 feature, supported in CLANG or GCC > 14
_BitInt(128) typedef unsigned uint128_t;

//the payload will contain the obfuscated data sent from client to server
typedef uint128_t payload_t;

// packet containing all the messages produced from the protocol
typedef struct __attribute__((packed)) packet_s{
    node_id_t client_id;
    payload_t payload[PUF_ITERATIONS];
    private_key_t hmac_sign;
    puf_state_t puf_state;
} packet_t;


typedef struct __attribute__((packed)) srv_packet_s{
    as_id_t server_id;
    uint128_t aggr_sum[PUF_ITERATIONS];
    uint128_t shares[PUF_ITERATIONS];

    puf_state_t puf_state;
    uint8_t active_count;
    private_key_t hmac_sign;
} srv_packet_t;


//******* common functions *******//

// define theta function to compute next link in the chain. Since we are using precomputed chains, this function only retrieves 
// the element from the uint128_t array.  

static inline uint128_t theta_function(const uint128_t* chain, int step);

static inline private_key_t calc_hmac_sign(const void* data, size_t data_len, private_key_t key);


/* FUNCTIONS IMPLEMENTATION */

static inline uint128_t theta_function(const uint128_t* chain, int step){
    return chain[step % CHAIN_LEN];
}

//made by copilot so check if correct (probabilmente no ma per ora me la faccio andare bene)
static inline private_key_t calc_hmac_sign(const void* data, size_t data_len, private_key_t key){
    //simple placeholder implementation of HMAC
    const uint8_t* bytes = (const uint8_t*)data;
    private_key_t hash = key;
    for(size_t i = 0; i < data_len; i++){
        hash = ((hash << 5) + hash) ^ bytes[i];  
    }
    return hash;
}



#endif